function data = filter_voltage(data, sampling_rate, bandpass)
%--------------------------------------------------------------------------
% filter_voltage.m - Filters a set of data channels using default filter
% settings (600-9000Hz bandpass). Data is converted to single precision.
%
% Usage: data = filter_voltage(data, sampling_rate, bandpass);
%
% Input:  data                  * CxD matrix of raw voltage data
%         sampling_rate         * sampling rate in Hz
%         bandpass (optional)   * 
% Output: data                  * CxD matrix of filtered data
%
% Written by Marshall Crumiller
% email: marshall.crumiller@mssm.edu
%--------------------------------------------------------------------------
if(~exist('bandpass','var') || isempty(bandpass))
    bandpass = [300 6000];
end

if(length(bandpass)==1)
    [b,a] = butter(2,bandpass/(sampling_rate/2),'high');
elseif(length(bandpass)==2)
    [b,a] = butter(2,[bandpass(1) bandpass(2)]/(sampling_rate/2),'bandpass');
else
    error('Invalid filter pass.  Should be 1x1 (highpass) or 1x2 (bandpass).');
end


%N = 3*round((1./min(bandpass))./(1./sampling_rate));
%b = fir1(N,bandpass./(sampling_rate./2));

%s_filt = filtfilt(b,1,data);

data=single(data);
for i = 1:size(data,1)
    data(i,:) = single(filtfilt(b,a,double(data(i,:))));
%    data(i,:)=single(filtfilt(b,1,double(data(i,:))));
end